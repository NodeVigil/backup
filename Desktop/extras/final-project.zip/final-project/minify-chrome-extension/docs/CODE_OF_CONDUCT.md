# Code of Conduct

## Minify – One-Click Page Summaries

### Our Pledge

We, as contributors and maintainers of **Minify**, pledge to make participation in our project and community a harassment-free, inclusive, and respectful experience for everyone—regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, education, nationality, personal appearance, race, religion, or sexual identity and orientation.

We are committed to fostering an open, welcoming, diverse, inclusive, and healthy community.

---

## Our Standards

Examples of behavior that contribute to a positive environment include:

- Being respectful, considerate, and professional in language and actions
- Welcoming newcomers and helping them learn and grow
- Giving and gracefully accepting constructive feedback
- Focusing on what is best for the community and project
- Showing empathy towards other community members
- Respecting differing viewpoints and experiences

Examples of unacceptable behavior include:

- Harassment, discrimination, or exclusionary behavior of any kind
- Trolling, insulting, or derogatory comments
- Personal or political attacks
- Public or private harassment
- Publishing others’ private information without explicit permission
- Sexualized language, imagery, or unwelcome advances
- Sustained disruptive behavior in discussions or pull requests

---

## Scope

This Code of Conduct applies to all project spaces, including but not limited to:

- GitHub repositories (issues, pull requests, discussions, and comments)
- Project documentation
- Community discussions and communications
- Any official Minify-related online or offline events

The Code of Conduct also applies when an individual is representing the project or its community in public spaces.

---

## Enforcement Responsibilities

Project maintainers are responsible for clarifying and enforcing acceptable behavior and are expected to take appropriate and fair corrective action in response to any behavior they deem inappropriate, threatening, offensive, or harmful.

Maintainers have the right and responsibility to remove, edit, or reject comments, commits, code, issues, or other contributions that violate this Code of Conduct.

---

## Enforcement Guidelines

Community leaders will follow these guidelines when addressing violations:

### 1. Correction

**Impact**: Use of inappropriate language or unintentional harmful behavior.
**Action**: A private or public clarification and guidance on expected behavior.

### 2. Warning

**Impact**: Repeated inappropriate behavior or a single significant violation.
**Action**: A formal warning with clear consequences for continued behavior.

### 3. Temporary Ban

**Impact**: Serious or repeated violations.
**Action**: Temporary removal from community participation for a specified period.

### 4. Permanent Ban

**Impact**: Severe harassment, threats, or sustained harmful behavior.
**Action**: Permanent removal from the community.

---

## Reporting Issues

If you experience or witness behavior that violates this Code of Conduct, please report it responsibly.

**Contact:**
📧 Email: **[security@minify-extension.dev](mailto:gouranga.samrat@gmail.com)**

All reports will be reviewed promptly and confidentially. The maintainers commit to respecting the privacy and safety of the reporter.

---

## Confidentiality

All complaints will be handled with discretion. Information will only be shared with those who need to know to resolve the issue.

---

## Commitment to Fairness

We are committed to enforcing this Code of Conduct consistently and fairly, regardless of contributor status or role within the project.

---

## Attribution

This Code of Conduct is adapted from the
**Contributor Covenant**, version 2.1
[https://www.contributor-covenant.org/](https://www.contributor-covenant.org/)

---

## Final Note

Minify is built to make the web more accessible and productive.
A respectful and inclusive community is essential to achieving that mission.

Thank you for being part of **Minify** 💙
