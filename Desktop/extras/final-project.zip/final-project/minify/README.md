# Minify – One-Click Page Summaries

#### Video Demo: <URL HERE>

#### Description:

**Minify** is a Chrome Extension (Manifest V3) that provides AI-powered web page summarization using Google's Gemini API. This project was developed as my final submission for CS50x 2026, representing the culmination of knowledge gained throughout the course in programming, web development, and software engineering principles.

## Project Overview

In today's information-overload era, we often encounter lengthy articles, blog posts, and documentation that require significant time to read and digest. Minify addresses this problem by leveraging artificial intelligence to generate concise, accurate summaries of web content in just one click. The extension empowers users to quickly grasp the key points of any article without sacrificing comprehension, making online reading more efficient and productive.

## Why I Built This

I chose to build a Chrome extension for several reasons. First, it allowed me to apply JavaScript knowledge from CS50x Week 8 (HTML, CSS, JavaScript) in a practical, real-world context. Second, browser extensions solve genuine user problems by integrating seamlessly into daily web browsing workflows. Finally, the Chrome Extension platform provided an excellent opportunity to explore asynchronous programming, API integration, and modern web technologies beyond the course curriculum.

Throughout development, I debated whether to build a web-based application (like a Flask app from Week 9) or a browser extension. I ultimately chose the extension route because it offers superior user experience—users can summarize content without leaving the page they're reading, making the tool more accessible and convenient.

## Technical Architecture

### Core Technologies

Minify is built entirely with front-end technologies, adhering to Chrome's Manifest V3 specifications:

- **JavaScript (ES6+)**: All logic, API communication, and DOM manipulation
- **HTML5**: User interface structure for popup and options pages
- **CSS3**: Dark-themed styling with custom properties for maintainability
- **Google Gemini API**: AI-powered text summarization using the `gemini-2.5-flash` model
- **Chrome Extension APIs**: `storage`, `tabs`, `scripting`, and `runtime` for extension functionality

### File Structure and Explanation

#### `manifest.json`

This is the heart of the Chrome extension. It defines:

- **Manifest Version 3**: The latest Chrome extension standard, which emphasizes security, performance, and privacy
- **Permissions**: `scripting` (content script injection), `activeTab` (current tab access), `storage` (API key storage)
- **Host Permissions**: `<all_urls>` to allow content extraction from any website
- **Entry Points**: Declares the popup UI (`popup.html`), options page (`options.html`), and background service worker (`background.js`)

I carefully selected minimal permissions to respect user privacy—Minify only accesses the active tab when the user explicitly clicks the extension icon, and it never collects or stores browsing history.

#### `background.js`

The background service worker handles extension lifecycle events. It contains a single event listener for `chrome.runtime.onInstalled`, which:

1. Checks if a Gemini API key exists in Chrome's sync storage
2. If no key is found, automatically opens the options page for first-time setup

This approach ensures a smooth onboarding experience—users are immediately prompted to configure the extension after installation. I debated using a persistent background page (Manifest V2 style) but chose the event-driven service worker model for better resource efficiency.

#### `content.js`

The content script is injected into all web pages (as specified in `manifest.json`). Its primary function is `getArticleText()`, which:

1. First attempts to extract content from the `<article>` tag (semantic HTML)
2. Falls back to collecting all `<p>` (paragraph) elements if no article tag exists
3. Returns concatenated text via message passing to the popup script

I chose this two-tier extraction strategy to maximize compatibility. Many modern news sites and blogs use semantic `<article>` tags, which provide the cleanest content extraction. However, older sites or non-standard layouts may not, so the paragraph fallback ensures broad compatibility.

The content script listens for messages from the popup via `chrome.runtime.onMessage` and responds with the extracted text. This message-passing architecture is necessary because content scripts run in isolated contexts and cannot directly communicate with popup scripts.

#### `popup.html` and `popup.js`

The popup interface is the user's primary interaction point. The HTML structure includes:

- A dropdown selector for summary type (Brief, Detailed, Bullet Points)
- A "Summarize" button that triggers the summarization workflow
- A "Copy" button for clipboard functionality
- A result display area that shows loading animations or summary text

The JavaScript logic orchestrates the entire summarization process:

1. **User clicks "Summarize"** → Displays loading state with animated spinner
2. **Retrieves API key** → Uses `chrome.storage.sync.get(['geminiApiKey'])`
3. **Queries active tab** → `chrome.tabs.query({active: true, currentWindow: true})`
4. **Sends message to content script** → `chrome.tabs.sendMessage(tabId, {type: 'GET_ARTICLE_TEXT'})`
5. **Receives article text** → Content script responds with extracted text
6. **Calls Gemini API** → `fetch()` request with prompt engineering
7. **Displays summary** → Updates result div with formatted text

I implemented comprehensive error handling for several edge cases:

- **API key not configured**: Prompts user to open options page
- **Content script connection failed**: Suggests refreshing the page (common when navigating to `chrome://` URLs)
- **Article extraction failed**: Informs user that the page isn't compatible
- **API errors**: Displays user-friendly error messages

One key design decision was text truncation—I limit article text to 20,000 characters before sending to the API. This prevents token limit errors and reduces API costs while still capturing enough content for accurate summarization. I tested various truncation thresholds (10k, 15k, 25k) and found 20k to be the optimal balance.

#### `options.html` and `options.js`

The options page provides a clean interface for API key configuration. It features:

- A password input field with toggle visibility (eye icon)
- A direct link to Google AI Studio for key creation
- Save functionality with success feedback
- Auto-close behavior after successful save

The JavaScript handles:

- Loading existing API keys on page load
- Toggling password visibility (switching between `type="password"` and `type="text"`)
- Saving keys to `chrome.storage.sync` (encrypted by Chrome and synced across devices)
- Displaying success messages and closing the tab after a brief delay

I debated whether to use local storage (`chrome.storage.local`) or sync storage (`chrome.storage.sync`). I chose sync storage so users who enable the extension on multiple devices only need to configure it once—their API key automatically syncs via their Google account.

#### `style.css`

The stylesheet implements a modern dark theme with:

- **CSS Custom Properties**: Centralized color scheme in `:root` for easy theming
- **Responsive Design**: Flexbox layouts that adapt to different screen sizes
- **Accessibility**: Proper contrast ratios, focus states, and semantic color usage
- **Animations**: Smooth loading spinner using CSS keyframes

The dark theme (`--bg: #0d1117`, `--panel: #161b22`) was inspired by GitHub's dark mode and provides reduced eye strain during extended use. I chose a blue accent color (`--accent: #58a6ff`) for interactive elements because blue is universally recognized as clickable in UI design.

### Prompt Engineering

The Gemini API integration required careful prompt engineering for different summary types:

**Brief (2-3 sentences):**
```javascript
`Provide a brief summary of the following article in 2-3 sentences:\n\n${text}`;
```

**Detailed (comprehensive):**
```javascript
`Provide a detailed summary of the following article, covering all main points and key details:\n\n${text}`;
```

**Bullet Points (5-7 points):**
```javascript
`Summarize the following article in 5-7 key points. Format each point as a line starting with "- " (dash followed by a space). Do not use asterisks or other bullet symbols, only use the dash. Keep each point concise and focused on a single key insight from the article:\n\n${text}`;
```

I experimented with various prompt structures and found that explicit formatting instructions (like "dash followed by a space") produce more consistent results than relying on the model's default behavior. I also set `temperature: 0.2` to prioritize factual accuracy over creative variation.

## Design Decisions and Trade-offs

### Manifest V3 vs. Manifest V2

I chose Manifest V3 despite the additional complexity because:

- It's the current standard (Manifest V2 is being phased out)
- Service workers are more resource-efficient than persistent background pages
- It demonstrates knowledge of modern extension architecture

The main challenge was adapting to the event-driven service worker model, which terminates after brief periods of inactivity. This required careful event listener management and avoiding persistent state.

### Security and Privacy

Security was paramount throughout development:

- **API Key Storage**: Used Chrome's encrypted sync storage (never plaintext)
- **HTTPS Only**: All API requests use secure connections
- **No Data Collection**: The extension never logs, tracks, or stores user data
- **Minimal Permissions**: Only requests necessary APIs (`activeTab` instead of `tabs`)

I considered implementing local caching of summaries but decided against it to respect user privacy—article content could contain sensitive information.

### User Experience

Several UX decisions improved usability:

- **Instant Feedback**: Loading animations prevent user confusion during API calls
- **Error Messages**: Clear, actionable error messages guide users to solutions
- **Auto-Configuration**: Options page opens automatically on first install
- **Copy to Clipboard**: One-click copying with visual feedback (checkmark icon)

I debated adding summary history or favorites functionality but opted for simplicity in this initial version. Feature creep is a common pitfall in software projects, and I wanted to ensure the core functionality was robust before adding complexity.

## Challenges and Learning Outcomes

### Technical Challenges

1. **Message Passing**: Understanding Chrome's asynchronous message-passing system required careful study of callback patterns and `chrome.runtime.lastError` handling.
2. **Content Script Injection**: Learning when and how content scripts are injected, and handling cases where they're not available (like on `chrome://` pages).
3. **API Integration**: Parsing Gemini's JSON response structure (`data?.candidates?.[0]?.content?.parts?.[0]?.text`) and handling various error responses.
4. **Asynchronous Programming**: Managing multiple async operations (storage retrieval, tab queries, API calls) with proper error propagation.

### CS50x Connections

This project directly applies concepts from multiple CS50x weeks:

- **Week 1-4 (C, Arrays, Algorithms, Memory)**: Understanding of data structures and algorithmic thinking informed my content extraction strategy
- **Week 6 (Python)**: While not using Python, the API integration logic mirrors request/response patterns learned in Python exercises
- **Week 7 (SQL)**: Database normalization principles influenced my decision to use minimal storage (only API keys)
- **Week 8 (HTML, CSS, JavaScript)**: Core web technologies used throughout the project
- **Week 9 (Flask)**: Understanding of client-server architecture translated to extension-API communication

## Future Enhancements

While Minify is fully functional, several potential improvements include:

- **Multi-Language Support**: Internationalization (i18n) for global users
- **Summary History**: Optional local storage of past summaries
- **Export Functionality**: Save summaries as PDF or text files
- **Firefox Support**: Cross-browser compatibility using WebExtensions API
- **Custom Prompts**: Allow users to define custom summarization styles
- **Offline Mode**: Cache summaries for offline access

## Conclusion

Minify represents more than just a Chrome extension—it's a practical application of CS50x principles in solving a real-world problem. The project challenged me to integrate multiple technologies, design user-centered interfaces, and think critically about software architecture and security.

Throughout development, I learned that building software is as much about making thoughtful design decisions as it is about writing code. Every choice—from which APIs to use, to how to handle errors, to what features to include—required careful consideration of trade-offs.

I'm proud of Minify and excited to continue developing it beyond CS50x. This project has given me confidence in my ability to build meaningful software that impacts users' daily lives.

**This was CS50x!**
